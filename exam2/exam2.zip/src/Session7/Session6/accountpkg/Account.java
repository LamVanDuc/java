package Session7.Session6.accountpkg;

public class Account {
    String AccountNumber;
    String AccountHolderName;
    String AccountType;
    double Balance;
}
